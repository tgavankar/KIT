Allgemeines

Der NonVisual Desktop Access (NVDA) ist ein freier Screen Reader f�r Windows, der blinden und sehbehinderten Menschen gleicherma�en es erm�glicht, Ihren Computer ohne zus�tzlichen Kostenaufwand nutzen zu k�nnen. NVDA erlaubt dem Benutzer herauszufinden, was auf dem Bildschirmpassiert, in dem es die Bildschirminformationen des Betriebssystems abfragt und eine Sprachausgabe und auch via Braillezeile zur Ausgabe von Informationen zur Verf�gung stellt. 

F�r weitere Informationen lesen Sie das beiliegende Benutzerhandbuch. Auf der NVDA-Webseite finden Sie ebenfalls mehr Informationen. 

Urheberrecht

Copyright � 2006-2010, das NVDA-Team

Der NVDA ist unter der GNU General Public License (Version 2.0) lizensiert worden. Dabei sind Sie berechtigt, diese Software nach belieben weiterzugeben und zu �ndern, solange Sie diese Software zusammen mit einer Kopie dieser Lizenz und den Quellcode an jeden weitergeben. Dies bezieht sich sowohl auf das Original sowie auf die von Ihnen modifizierte Kopie und s�mtliche Software, die Code-Fragmente von NVDA enthalten.

F�r weitere Informationen k�nnen Sie die beiliegende englischsprachige Lizenz lesen.
