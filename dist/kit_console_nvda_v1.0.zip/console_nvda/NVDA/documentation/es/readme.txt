NonVisual Desktop Access (NVDA)
URL: http://www.nvda-project.org/

NonVisual Desktop Access (NVDA) es un lector de pantalla de c�digo abierto (y libre) para el Sistema Operativo Windows. Este programa puede capacitar a la gente ciega o deficiente visual el acceder a ordenadores ejecutando Windows por un coste no mayor que una persona vidente. NVDA permite al usuario conoc�r qu� est� ocurriendo en la pantalla preguntando al Sistema Operativo y utilizando  un sintetizador de voz para la informaci�n de salida.

Para m�s informaci�n, por favor mira la gu�a del usuario inclu�da. Pueden ser encontrados informaci�n adicional y recursos en el Sitio Web de NVDA.

Derechos Reservados (Copyright):
Derechos Reservados (C) 2006-2008 por los Colaboradores de NVDA <http://www.nvda-project.org/>
NVDA est� cubierto por la GNU General Public License (Versi�n 2). Eres libre de compartir o cambiar este programa de cualquier manera que quieras aunque distribuye la licencia junto con el programa, y haz que todo el c�digo fuente est� disponible para cualquiera que lo quiera. Esto se aplica al original y a las copias modificadas del programa, m�s cualquier programa que utilice c�digo tomado de este programa.
Para m�s detalles, puedes ver la licencia online (en ingl�s) en:
http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
O mira el fichero Copying.txt que viene con este software.

