NonVisual Desktop Access (NVDA)
Endere�o: http://www.nvda-project.org/

O NonVisual Desktop Access (NVDA) � um leitor de ecr� livre e open source para o sistema operativo Microsoft Windows. Este software fornece �s pessoas cegas o acesso a computadores que corram o Windows sem custos adicionais quando comparados aos das pessoas com vis�o. O NVDA permite ao utilizador saber o que est� a aparecer no ecr� atrav�s da consulta do sistema operativo e usa um sintetizador de voz e/ou uma linha Braille para transmitir a informa��o.

Para mais informa��es, por favor veja o guia do utilizador que j� vem inclu�do com este leitor de ecr�. As informa��es adicionais e recursos podem ser encontrados no web site do NVDA.

Copyright:
Copyright (C) 2006-2010 Contribuidores do NVDA
O NVDA est� coberto pela GNU General Public License (Vers�o 2). � livre para partilhar ou alterar este programa da forma que pretender desde que distribua sempre a licen�a, software e todo o respectivo c�digo dispon�vel. Para quem pretender este programa, as regras anteriormente mencionadas aplicam-se ao software original e a todas as c�pias modificadas, incluindo todos os programas que contenham c�digo descendente deste.
Para mais detalhes, pode ver a licen�a online em:
http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
Ou leia o ficheiro Copying.txt que acompanha este software.
