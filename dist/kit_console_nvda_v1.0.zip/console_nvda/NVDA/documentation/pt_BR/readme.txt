﻿Acesso Não-Visual ao Ambiente de Trabalho (NVDA)
Endereço eletrônico: http://www.nvda-project.org/

O NVDA (Acesso Não-Visual ao Ambiente de Trabalho) é um leitor de telas gratuito e de código aberto para o sistema operacional Microsoft Windows. Ele habilita pessoas cegas ou com baixa visão a acessar computadores que rodam Windows a um custo não maior que uma pessoa vidente. O NVDA permite ao usuário saber o que se passa na tela, consultando o sistema e usando fala sintética para transmitir as informações.

Para mais informações, consulte por favor o guia do usuário incluso neste pacote. Outras fontes e informações encontram-se na página do NVDA na Internet.

Copyright:
Copyright (C) 2006-2011 Colaboradores do NVDA, <http://www.nvda-project.org/>
O NVDA encontra-se sob a Licença Pública Geral GNU (versão 2). Pode distribuí-lo e modificá-lo à vontade, contanto que distribua a licença com o programa e ofereça o código fonte a quem o queira. Isso aplica-se às cópias intactas e também às modificadas, bem como a outros programas que usem código decendente deste.
Para mais detalhes, veja a licença na Internet em:
http://www.magnux.org/doc/GPL-pt_BR.txt
ou consulte o arquivo "copying.txt" que vem com este programa.
Você pode também lê-lo em português, localizando-o na pasta nvda\documentation\pt_BR