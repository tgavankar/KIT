NonVisual Desktop Access (NVDA)
http://www.nvda-project.org/

NonVisual Desktop Access (NVDA) to darmowe i wolne oprogramowanie ud�wi�kawiaj�ce dla systemu operacyjnego Microsoft Windows. Program ten pozwala osobom niewidomym i niedowidz�cym korzysta� z komputera bez ponoszenia wi�kszych koszt�w ni� osoby widz�ce. Informacja o tym, co jest widoczne na ekranie, przekazywana jest przez syntezator mowy, NVDA pe�ni wi�c rol� czytnika ekranowego.

Wi�cej wiadomo�ci o programie mo�na znale�� w do��czonym podr�czniku u�ytkownika. Dodatkowe informacje i zasoby znajduj� si� na stronie internetowej NVDA.

Mo�esz odwiedzi� tak�e polsk� stron� internetow� po�wi�con� programowi i jego u�ytkownikom pod adresem: www.nvda.pl

Copyright (C) 2006-2009 Wsp�autorzy NVDA <http://www.nvda-project.org/>
NVDA podlega pod GNU General Public License (wersja 2). Mo�esz za darmo udost�pnia� ten program i dowolnie zmienia� go, pod warunkiem, �e do��czysz do niego t� licencj� oraz udost�pnisz pe�ny kod �r�d�owy ka�demu zainteresowanemu. Dotyczy to zar�wno oryginalnej wersji programu, jak i jego zmienionych kopii, a tak�e ka�dego innego oprogramowania, kt�re korzysta z kodu zaczerpni�tego z tego programu.
Dok�adne brzmienie licencji znajdziesz online pod adresem:
http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
oraz w pliku copying.txt, kt�ry zosta� dostarczony wraz z programem.