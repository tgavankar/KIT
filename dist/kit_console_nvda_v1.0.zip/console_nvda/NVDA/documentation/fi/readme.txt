Non-Visual Desktop Access (NVDA)
URL: http://www.nvda-project.org/

Non-Visual Desktop Access (NVDA) on avoimeen l�hdekoodiin perustuva ruudunlukuohjelma Windows-k�ytt�j�rjestelm�lle. NVDA:n avulla sokeat ja heikkon�k�iset voivat k�ytt�� Windowsia samaan hintaan kuin n�kev�tkin henkil�t. NVDA tulostaa tiedot ruudun tapahtumista synteettisen� puheena ja pistekirjoituksella.

Lis�tietoja saat katsomalla mukana toimitettua k�ytt�ohjetta. NVDA:n web-sivustolta l�ytyy my�s lis�tietoja ja -resursseja.

Tekij�noikeus:
Copyright (C) 2006-2010 NVDA:n tekij�t <http://www.nvda-project.org/>
NVDA on suojattu GNU General Public License (versio 2) -lisenssill�. Voit vapaasti jakaa tai muuttaa t�t� ohjelmistoa miten tahansa, kunhan jaat lisenssi� sen mukana ja pid�t l�hdekoodin kaikkien saatavilla. T�m� koskee sek� muokattuja ett� alkuper�isi� ohjelmistokopioita, lis�ksi kaikkia t�m�n ohjelmiston koodia k�ytt�vi� ohjelmistoja. Saadaksesi lis�tietoja, voit tarkastella lisenssi� verkossa osoitteessa:
http://www.gnu.org/licenses/old-licenses/gpl-2.0.html,
tai katso t�m�n ohjelmiston mukana toimitettua Copying.txt-tiedostoa.
