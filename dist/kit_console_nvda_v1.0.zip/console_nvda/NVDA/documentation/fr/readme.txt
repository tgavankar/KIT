NonVisual Desktop Access (NVDA)
URL: http://www.nvda-project.org/

NonVisual desktop access (NVDA) est un lecteur d'�cran open-source et gratuit
pour le syst�me d'exploitation Microsoft Windows.
il permet aux personnes aveugles ou malvoyantes d'utiliser un ordinateur
sous Windows sans co�t additionnel par rapport � une personne voyante.
NVDA permet � l'utilisateur de savoir ce qui se passe � l'�cran
en interrogeant le syst�me et en restituant l'information
au moyen d'une synth�se vocale.

Pour plus d'informations, veuillez consulter le guide de l'utilisateur
inclus dans le logiciel.
Des informations suppl�mentaires sont �galement disponibles sur le site
web de NVDA.

Copyright:
Copyright (C) 2006-2008 NVDA Contributors <http://www.nvda-project.org/>
NVDA est couvert par la licence publique g�n�rale GNU (FPL Version 2).
Vous �tes libre de partager ou modifier ce logiciel de quelque fa�on que vous
voulez tant que vous distribuez la licence avec le logiciel,
et rendez tout le code source disponible � qui le veut. Ceci s'applique
aux copies originales et modifi�es du logiciel, ainsi qu'� n'importe
quel logiciel utilisant du code tir� de ce logiciel.
Pour plus de d�tails, vous pouvez consulter la licence en ligne sur:
http://www.gnu.org/licenses/gpl.html
Ou le fichier Copying.txt fourni avec ce logiciel.
