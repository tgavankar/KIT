NonVisual Desktop Access (NVDA)
URL: http://www.nvda-project.org/

NonVisual Desktop Access (NVDA) este un cititor de ecran gratuit �i open source pentru sistemul de operare Microsoft Windows. Acest program poate permite persoanelor oarbe �i cu deficien�e de vedere s� acceseze computere care folosesc Windows f�r� s� pl�teasc� �n plus fa�� de o persoan� care poate vedea. NVDA permite utilizatorului s� afle ce se �nt�mpl� pe ecran interog�nd sistemul de operare �i folosind un sintetizator de voce pentru a comunica informa�ia.

Pentru mai multe informa�ii, v� rug�m citi�i ghidul utilizatorului inclus �n pachet. Informa�ii adi�ionale �i resurse pot fi g�site pe site-ul NVDA.

Copyright:
Copyright (C) 2006-2010 NVDA Contributors
NVDA este acoperit de Brevetul Public General GNU (Versiunea 2).
Sunte�i liber s� distribui�i sau s� schimba�i acest program �n orice mod dori�i at�ta timp c�t distribui�i �i brevetul al�turi de program �i pune�i codul surs� la dispozi�ia oricui �l dore�te. Asta se aplic� at�t originalului c�t �i copiilor modificate ale programului, plus oric�rui alt program care folose�te codul extras din acest program.
Pentru alte detalii, pute�i vedea brevetul online la:
http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
Sau citi�i fi�ierul Copying.txt care a venit cu acest program.
